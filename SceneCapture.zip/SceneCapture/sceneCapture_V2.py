import tkinter as tk
from tkinter import filedialog
import cv2
import numpy as np
import datetime
import os
from PIL import Image, ImageTk

# rembg for background removal
# pip install rembg onnxruntime
from rembg import remove

class App:
    def __init__(self, master):
        self.master = master
        self.master.title("Webcam Capture and Analysis")

        # Initialize webcam
        self.cap = cv2.VideoCapture(0)

        # Variables to store captures, masks, centroids, etc.
        self.photo1 = None  # First captured image (in RGB)
        self.photo2 = None  # Second captured image (in RGB)
        self.mask1 = None
        self.mask2 = None
        self.centroid1 = None
        self.centroid2 = None
        self.angle_difference = None

        # Simple horizontal FOV assumption (in degrees)
        self.fov = 60

        # 0 => no photo yet, 1 => first captured, 2 => second captured
        self.current_capture = 0

        # GUI Elements

        # Live webcam feed
        self.video_label = tk.Label(master)
        self.video_label.pack()

        # Button to capture images
        self.capture_button = tk.Button(master, text="Take First Picture", command=self.capture_photo)
        self.capture_button.pack()

        # Frame to hold the two captured images
        self.captured_frame = tk.Frame(master)
        self.captured_frame.pack()

        # Create placeholder images (light gray)
        self.placeholder_imgtk = self.create_placeholder_image(200, 150)

        # Labels for the captured images
        self.photo1_label = tk.Label(self.captured_frame, image=self.placeholder_imgtk)
        self.photo1_label.grid(row=0, column=0, padx=5, pady=5)

        self.photo2_label = tk.Label(self.captured_frame, image=self.placeholder_imgtk)
        self.photo2_label.grid(row=0, column=1, padx=5, pady=5)

        # Angle difference label
        self.angle_label = tk.Label(master, text="Angle Difference: N/A")
        self.angle_label.pack(pady=5)

        # Export button
        self.export_button = tk.Button(master, text="Export Data", command=self.export_data)
        self.export_button.pack(pady=5)

        # Start updating the webcam feed
        self.update_video()

    def create_placeholder_image(self, width, height):
        """
        Create a blank (light gray) image and convert it to an ImageTk.PhotoImage
        so it can be displayed in Tkinter as a placeholder.
        """
        placeholder = np.full((height, width, 3), 200, dtype=np.uint8)  # light gray
        pil_placeholder = Image.fromarray(placeholder)
        return ImageTk.PhotoImage(image=pil_placeholder)

    def update_video(self):
        """
        Continuously grab frames from the webcam and update the Tkinter label.
        """
        ret, frame_bgr = self.cap.read()
        if ret:
            # Convert BGR to RGB for consistency
            frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            self.current_frame = frame_rgb.copy()

            # Convert to PIL for Tk
            img = Image.fromarray(frame_rgb)
            imgtk = ImageTk.PhotoImage(image=img)
            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)

        # Schedule the next frame
        self.master.after(10, self.update_video)

    def capture_photo(self):
        """
        Capture logic: If no photo yet, capture the first. If first is captured, capture the second.
        After the second, calculate the angle difference.
        """
        if not hasattr(self, 'current_frame') or self.current_frame is None:
            return  # Safety check

        if self.current_capture == 0:
            # First capture
            self.photo1 = self.current_frame.copy()  # Already in RGB
            self.mask1, self.centroid1 = self.segment_person(self.photo1)

            # Display first photo in upper left
            img_pil = Image.fromarray(self.photo1)
            imgtk = ImageTk.PhotoImage(image=img_pil)
            self.photo1_label.imgtk = imgtk
            self.photo1_label.configure(image=imgtk)

            self.current_capture = 1
            self.capture_button.config(text="Take Second Picture")

        elif self.current_capture == 1:
            # Second capture
            self.photo2 = self.current_frame.copy()
            self.mask2, self.centroid2 = self.segment_person(self.photo2)

            # Display second photo in upper right
            img_pil = Image.fromarray(self.photo2)
            imgtk = ImageTk.PhotoImage(image=img_pil)
            self.photo2_label.imgtk = imgtk
            self.photo2_label.configure(image=imgtk)

            self.current_capture = 2
            # Calculate angle difference
            self.calculate_angle_difference()

    def segment_person(self, image_rgb):
        """
        Uses rembg to remove the background from the image.
        Returns a binary mask (person=255, background=0) and the centroid of the largest person region.
        """
        # Convert numpy array to PIL Image
        pil_img = Image.fromarray(image_rgb)

        # Remove background => returns an RGBA image
        out_pil = remove(pil_img)
        out_np = np.array(out_pil)  # shape: (H, W, 4) with RGBA channels

        # The alpha channel indicates the person region
        alpha = out_np[:, :, 3]  # 0..255
        mask = np.where(alpha > 128, 255, 0).astype(np.uint8)

        # Find largest contour to compute centroid
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        h, w = mask.shape
        centroid = (w // 2, h // 2)  # default to center

        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            M = cv2.moments(largest_contour)
            if M["m00"] != 0:
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
                centroid = (cX, cY)

        return mask, centroid

    def calculate_angle_difference(self):
        """
        Approximate angle calculation based on horizontal offset of centroid
        from the center. Then compute absolute difference between two angles.
        """
        width = self.photo1.shape[1]
        center_x = width / 2.0

        # Angle of photo1
        angle1 = ((self.centroid1[0] - center_x) / center_x) * (self.fov / 2.0)
        # Angle of photo2
        angle2 = ((self.centroid2[0] - center_x) / center_x) * (self.fov / 2.0)

        self.angle_difference = abs(angle2 - angle1)
        self.angle_label.config(text=f"Angle Difference: {self.angle_difference:.2f}°")

    def export_data(self):
        """
        If both photos captured, opens directory selection, creates timestamped folder,
        saves photos (PNG), masks (JPG), and a text file with angle difference & centroids.
        Then resets the GUI.
        """
        if self.current_capture < 2:
            return  # Only export if both photos exist

        folder_selected = filedialog.askdirectory()
        if not folder_selected:
            return
        
        # Get the experiment number by counting the number of folders in the selected directory that start with the same date
        experiment_number = len([name for name in os.listdir(folder_selected) if name.startswith(datetime.datetime.now().strftime("%Y%m%d"))])

        # Create timestamped folder
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H-%M-%S")
        folder_name = f"{timestamp}_angle-{self.angle_difference:.2f}_experiment-{experiment_number}"
        full_path = os.path.join(folder_selected, folder_name)
        os.makedirs(full_path, exist_ok=True)

        # Save the two photos (convert from RGB to BGR before cv2.imwrite)
        photo1_path = os.path.join(full_path, "photo1.png")
        photo2_path = os.path.join(full_path, "photo2.png")
        cv2.imwrite(photo1_path, cv2.cvtColor(self.photo1, cv2.COLOR_RGB2BGR))
        cv2.imwrite(photo2_path, cv2.cvtColor(self.photo2, cv2.COLOR_RGB2BGR))

        # Save the two masks as JPG
        mask1_path = os.path.join(full_path, "photo1.jpg")
        mask2_path = os.path.join(full_path, "photo2.jpg")
        cv2.imwrite(mask1_path, self.mask1)
        cv2.imwrite(mask2_path, self.mask2)

        # Save data to text file
        data_path = os.path.join(full_path, "data.txt")
        with open(data_path, "w") as f:
            f.write(f"Angle Difference: {self.angle_difference:.2f}\n")
            f.write(f"Photo1 Centroid: {self.centroid1}\n")
            f.write(f"Photo2 Centroid: {self.centroid2}\n")

        print("Data exported successfully.")
        self.reset_gui()

    def reset_gui(self):
        """
        Clears all stored data, resets the GUI to its initial state.
        """
        self.photo1 = None
        self.photo2 = None
        self.mask1 = None
        self.mask2 = None
        self.centroid1 = None
        self.centroid2 = None
        self.angle_difference = None
        self.current_capture = 0

        # Reset the image labels to placeholders
        self.photo1_label.configure(image=self.placeholder_imgtk)
        self.photo2_label.configure(image=self.placeholder_imgtk)
        self.photo1_label.imgtk = self.placeholder_imgtk
        self.photo2_label.imgtk = self.placeholder_imgtk

        # Reset angle label and capture button
        self.angle_label.config(text="Angle Difference: N/A")
        self.capture_button.config(text="Take First Picture")

    def on_closing(self):
        """
        Release resources when the window closes.
        """
        self.cap.release()
        self.master.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()
