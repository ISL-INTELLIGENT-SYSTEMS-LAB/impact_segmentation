import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import os
import time
from scipy.spatial import distance as dist

class CameraApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Camera Capture App")
        
        self.video_capture = cv2.VideoCapture(0)
        
        self.canvas = tk.Canvas(root, width=640, height=480)
        self.canvas.pack()
        
        self.img1_label = tk.Label(root)
        self.img1_label.pack(side=tk.LEFT)
        self.img2_label = tk.Label(root)
        self.img2_label.pack(side=tk.RIGHT)
        
        self.capture_button = tk.Button(root, text="Capture Image", command=self.capture_image)
        self.capture_button.pack()
        
        self.export_button = tk.Button(root, text="Export Data", command=self.export_data)
        self.export_button.pack()
        
        self.image_count = 0
        self.images = []
        self.masks = []
        self.subject_positions = []
        self.update_feed()
    
    def update_feed(self):
        ret, frame = self.video_capture.read()
        if ret:
            self.current_frame = frame.copy()
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame)
            imgtk = ImageTk.PhotoImage(image=img)
            self.canvas.create_image(0, 0, anchor=tk.NW, image=imgtk)
            self.canvas.imgtk = imgtk
        self.root.after(10, self.update_feed)
    
    def capture_image(self):
        if self.image_count < 2:
            img = self.current_frame.copy()
            self.images.append(img)
            mask = self.segment_object(img)
            self.masks.append(mask)
            
            if self.image_count == 0:
                self.display_image(img, self.img1_label)
            else:
                self.display_image(img, self.img2_label)
                self.calculate_angle_difference()
            
            self.image_count += 1
    
    def display_image(self, img, label):
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(img)
        img.thumbnail((200, 200))
        imgtk = ImageTk.PhotoImage(image=img)
        label.config(image=imgtk)
        label.imgtk = imgtk
    
    def segment_object(self, img):
        mask = np.zeros(img.shape[:2], np.uint8)
        bgd_model = np.zeros((1, 65), np.float64)
        fgd_model = np.zeros((1, 65), np.float64)
        rect = (50, 50, img.shape[1]-100, img.shape[0]-100)
        cv2.grabCut(img, mask, rect, bgd_model, fgd_model, 5, cv2.GC_INIT_WITH_RECT)
        mask = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
        segmented = img * mask[:, :, np.newaxis]
        return segmented
    
    def calculate_angle_difference(self):
        if len(self.images) == 2:
            img1, img2 = self.images
            gray1, gray2 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY), cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
            sift = cv2.SIFT_create()
            kp1, des1 = sift.detectAndCompute(gray1, None)
            kp2, des2 = sift.detectAndCompute(gray2, None)
            
            bf = cv2.BFMatcher()
            matches = bf.knnMatch(des1, des2, k=2)
            
            good_matches = []
            for m, n in matches:
                if m.distance < 0.75 * n.distance:
                    good_matches.append(m)
            
            if len(good_matches) > 10:
                pts1 = np.float32([kp1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
                pts2 = np.float32([kp2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)
                angle_diff = self.compute_angle(pts1, pts2)
                tk.messagebox.showinfo("Angle Difference", f"Calculated Angle Difference: {angle_diff:.2f} degrees")
    
    def compute_angle(self, pts1, pts2):
        shift_vectors = pts2 - pts1
        angles = np.arctan2(shift_vectors[:, 0, 1], shift_vectors[:, 0, 0])
        avg_angle = np.mean(np.degrees(angles))
        return avg_angle
    
    def export_data(self):
        if len(self.images) < 2:
            tk.messagebox.showerror("Error", "Capture both images first!")
            return
        
        save_dir = filedialog.askdirectory()
        if not save_dir:
            return
        
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        folder_name = f"{timestamp}_ObjectDetected"
        path = os.path.join(save_dir, folder_name)
        os.makedirs(path, exist_ok=True)
        
        cv2.imwrite(os.path.join(path, "image1.png"), self.images[0])
        cv2.imwrite(os.path.join(path, "image2.png"), self.images[1])
        cv2.imwrite(os.path.join(path, "mask1.jpg"), self.masks[0])
        cv2.imwrite(os.path.join(path, "mask2.jpg"), self.masks[1])
        
        angle_diff = self.compute_angle(np.array(self.subject_positions[0]), np.array(self.subject_positions[1]))
        with open(os.path.join(path, "data.txt"), "w") as f:
            f.write(f"Angle Difference: {angle_diff:.2f} degrees\n")
        
        tk.messagebox.showinfo("Success", f"Data saved in {path}")
    
    def close(self):
        self.video_capture.release()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = CameraApp(root)
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()
