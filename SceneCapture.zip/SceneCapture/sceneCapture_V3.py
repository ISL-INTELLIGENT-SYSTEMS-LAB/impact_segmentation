import tkinter as tk
from tkinter import filedialog
import cv2
import numpy as np
import datetime
import os
from PIL import Image, ImageTk, ImageDraw
import math

# rembg for background removal
# pip install rembg onnxruntime
from rembg import remove

class App:
    def __init__(self, master):
        self.master = master
        self.master.title("Webcam Capture and Analysis")

        # Initialize webcam
        self.cap = cv2.VideoCapture(0)

        # Variables to store captures, masks, centroids, and additional image data
        self.photo1 = None  # First captured image (RGB)
        self.photo2 = None  # Second captured image (RGB)
        self.mask1 = None
        self.mask2 = None
        self.centroid1 = None
        self.centroid2 = None
        self.area1 = None   # Subject area in photo1
        self.area2 = None   # Subject area in photo2
        self.angle_difference = None

        # Assumed horizontal field of view (in degrees)
        self.fov = 60

        # Capture state: 0 => no photo yet, 1 => first captured, 2 => second captured
        self.current_capture = 0

        # GUI Elements

        # Live webcam feed
        self.video_label = tk.Label(master)
        self.video_label.pack()

        # Button to capture images
        self.capture_button = tk.Button(master, text="Take First Picture", command=self.capture_photo)
        self.capture_button.pack()

        # Frame for the two captured images
        self.captured_frame = tk.Frame(master)
        self.captured_frame.pack()

        # Placeholder image (light gray)
        self.placeholder_imgtk = self.create_placeholder_image(200, 150)

        # Labels for the captured images
        self.photo1_label = tk.Label(self.captured_frame, image=self.placeholder_imgtk)
        self.photo1_label.grid(row=0, column=0, padx=5, pady=5)
        self.photo2_label = tk.Label(self.captured_frame, image=self.placeholder_imgtk)
        self.photo2_label.grid(row=0, column=1, padx=5, pady=5)

        # Angle difference label
        self.angle_label = tk.Label(master, text="Angle Difference: N/A")
        self.angle_label.pack(pady=5)

        # Label to display the circle diagram
        self.angle_circle_label = tk.Label(master)
        self.angle_circle_label.pack(pady=5)

        # Export button
        self.export_button = tk.Button(master, text="Export Data", command=self.export_data)
        self.export_button.pack(pady=5)

        # Start updating the webcam feed
        self.update_video()

    def create_placeholder_image(self, width, height):
        """Creates a blank light-gray placeholder image."""
        placeholder = np.full((height, width, 3), 200, dtype=np.uint8)
        pil_placeholder = Image.fromarray(placeholder)
        return ImageTk.PhotoImage(image=pil_placeholder)

    def update_video(self):
        """Continuously grabs frames from the webcam and updates the display."""
        ret, frame_bgr = self.cap.read()
        if ret:
            frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            self.current_frame = frame_rgb.copy()
            img = Image.fromarray(frame_rgb)
            imgtk = ImageTk.PhotoImage(image=img)
            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)
        self.master.after(10, self.update_video)

    def capture_photo(self):
        """Handles the capture sequence: first then second capture; then calculates the angle difference."""
        if not hasattr(self, 'current_frame') or self.current_frame is None:
            return

        if self.current_capture == 0:
            self.photo1 = self.current_frame.copy()  # RGB
            self.mask1, self.centroid1, self.area1 = self.segment_person(self.photo1)
            img_pil = Image.fromarray(self.photo1)
            imgtk = ImageTk.PhotoImage(image=img_pil)
            self.photo1_label.imgtk = imgtk
            self.photo1_label.configure(image=imgtk)
            self.current_capture = 1
            self.capture_button.config(text="Take Second Picture")
        elif self.current_capture == 1:
            self.photo2 = self.current_frame.copy()
            self.mask2, self.centroid2, self.area2 = self.segment_person(self.photo2)
            img_pil = Image.fromarray(self.photo2)
            imgtk = ImageTk.PhotoImage(image=img_pil)
            self.photo2_label.imgtk = imgtk
            self.photo2_label.configure(image=imgtk)
            self.current_capture = 2
            self.calculate_angle_difference()

    def segment_person(self, image_rgb):
        """
        Uses rembg to remove the background from the image.
        Returns:
          - A binary mask (person=255, background=0),
          - The centroid of the largest detected person region,
          - The area of that region.
        """
        pil_img = Image.fromarray(image_rgb)
        out_pil = remove(pil_img)
        out_np = np.array(out_pil)  # (H, W, 4) RGBA
        alpha = out_np[:, :, 3]
        mask = np.where(alpha > 128, 255, 0).astype(np.uint8)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        h, w = mask.shape
        centroid = (w // 2, h // 2)
        area = 0.0
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(largest_contour)
            M = cv2.moments(largest_contour)
            if M["m00"] != 0:
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
                centroid = (cX, cY)
        return mask, centroid, area

    def calculate_angle_difference(self):
        """
        Calculates approximate angles for both photos based on the horizontal offset of the subject's centroid.
        Updates the angle difference and generates the circle diagram.
        """
        width = self.photo1.shape[1]
        center_x = width / 2.0

        # Angle based on horizontal offset from center (assuming a fixed FOV)
        angle1 = ((self.centroid1[0] - center_x) / center_x) * (self.fov / 2.0)
        angle2 = ((self.centroid2[0] - center_x) / center_x) * (self.fov / 2.0)

        self.angle_difference = abs(angle2 - angle1)
        self.angle_label.config(text=f"Angle Difference: {self.angle_difference:.2f}")

        # Generate and display the circle diagram
        circle_img = self.generate_angle_circle_image(angle1, angle2)
        circle_imgtk = ImageTk.PhotoImage(circle_img)
        self.angle_circle_label.imgtk = circle_imgtk
        self.angle_circle_label.config(image=circle_imgtk)

    def generate_angle_circle_image(self, angle1, angle2, width=200, height=200):
        """
        Draws a circle with:
          - A blue dot at the center (subject),
          - Two red points (the camera angles),
          - Lines from the center to each red point.
        """
        img = Image.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(img)
        cx, cy = width // 2, height // 2
        radius = min(cx, cy) - 10

        # Draw outer circle
        draw.ellipse([cx - radius, cy - radius, cx + radius, cy + radius],
                     outline='black', width=2)

        # Draw center point (subject)
        center_dot_r = 5
        draw.ellipse([cx - center_dot_r, cy - center_dot_r, cx + center_dot_r, cy + center_dot_r],
                     fill='blue')

        # Convert angles to radians and compute positions for red dots
        rad1 = math.radians(angle1)
        rad2 = math.radians(angle2)
        x1 = cx + radius * math.cos(rad1)
        y1 = cy + radius * math.sin(rad1)
        x2 = cx + radius * math.cos(rad2)
        y2 = cy + radius * math.sin(rad2)

        dot_r = 5
        draw.ellipse([x1 - dot_r, y1 - dot_r, x1 + dot_r, y1 + dot_r], fill='red')
        draw.ellipse([x2 - dot_r, y2 - dot_r, x2 + dot_r, y2 + dot_r], fill='red')

        # Draw lines from the center to the red dots
        draw.line((cx, cy, x1, y1), fill='red', width=2)
        draw.line((cx, cy, x2, y2), fill='red', width=2)

        return img

    def export_data(self):
        """
        Exports:
          - Two photos (PNG),
          - Two masks (JPG),
          - The circle diagram ("Camera_pos_diagram.png"),
          - A data.txt file containing angle difference, centroids, image dimensions, and subject areas.
        The folder is named using the format:
          YYYYMMDD_HH-MM-SS_angle-{angle_difference}_exp-{experiment_number}
        After export, the GUI resets.
        """
        if self.current_capture < 2:
            return

        folder_selected = filedialog.askdirectory()
        if not folder_selected:
            return

        # Get experiment number by counting folders starting with today's date
        today_prefix = datetime.datetime.now().strftime("%Y%m%d")
        experiment_number = len([name for name in os.listdir(folder_selected)
                                 if name.startswith(today_prefix)])

        # Create timestamped folder using "exp" instead of "experiment"
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H-%M-%S")
        folder_name = f"{timestamp}_angle-{self.angle_difference:.2f}_exp-{experiment_number}"
        full_path = os.path.join(folder_selected, folder_name)
        os.makedirs(full_path, exist_ok=True)

        # Save photos (convert RGB to BGR)
        photo1_path = os.path.join(full_path, "photo1.png")
        photo2_path = os.path.join(full_path, "photo2.png")
        cv2.imwrite(photo1_path, cv2.cvtColor(self.photo1, cv2.COLOR_RGB2BGR))
        cv2.imwrite(photo2_path, cv2.cvtColor(self.photo2, cv2.COLOR_RGB2BGR))

        # Save masks as JPG
        mask1_path = os.path.join(full_path, "photo1.jpg")
        mask2_path = os.path.join(full_path, "photo2.jpg")
        cv2.imwrite(mask1_path, self.mask1)
        cv2.imwrite(mask2_path, self.mask2)

        # Save circle diagram as "Camera_pos_diagram.png"
        # Recalculate angles for consistency
        width = self.photo1.shape[1]
        center_x = width / 2.0
        angle1 = ((self.centroid1[0] - center_x) / center_x) * (self.fov / 2.0)
        angle2 = ((self.centroid2[0] - center_x) / center_x) * (self.fov / 2.0)
        circle_img = self.generate_angle_circle_image(angle1, angle2)
        circle_img_path = os.path.join(full_path, "Camera_pos_diagram.png")
        circle_img.save(circle_img_path)

        # Save additional image data in data.txt
        data_path = os.path.join(full_path, "data.txt")
        with open(data_path, "w") as f:
            f.write(f"Angle Difference: {self.angle_difference:.2f}\n")
            f.write(f"Photo1 Centroid: {self.centroid1}\n")
            f.write(f"Photo2 Centroid: {self.centroid2}\n")
            f.write(f"Photo1 Dimensions: {self.photo1.shape[1]}x{self.photo1.shape[0]}\n")
            f.write(f"Photo2 Dimensions: {self.photo2.shape[1]}x{self.photo2.shape[0]}\n")
            f.write(f"Photo1 Subject Area: {self.area1:.2f}\n")
            f.write(f"Photo2 Subject Area: {self.area2:.2f}\n")

        print("Data exported successfully.")
        self.reset_gui()

    def reset_gui(self):
        """Resets all stored data and GUI elements to their initial state."""
        self.photo1 = None
        self.photo2 = None
        self.mask1 = None
        self.mask2 = None
        self.centroid1 = None
        self.centroid2 = None
        self.area1 = None
        self.area2 = None
        self.angle_difference = None
        self.current_capture = 0

        self.photo1_label.configure(image=self.placeholder_imgtk)
        self.photo2_label.configure(image=self.placeholder_imgtk)
        self.photo1_label.imgtk = self.placeholder_imgtk
        self.photo2_label.imgtk = self.placeholder_imgtk

        self.angle_label.config(text="Angle Difference: N/A")
        self.angle_circle_label.config(image='')
        self.angle_circle_label.imgtk = None
        self.capture_button.config(text="Take First Picture")

    def on_closing(self):
        """Releases resources on application close."""
        self.cap.release()
        self.master.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()
